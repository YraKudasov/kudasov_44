var searchData=
[
  ['main_0',['main',['../kudasov__44_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97',1,'kudasov_44.cpp']]]
];
