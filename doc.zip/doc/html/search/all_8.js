var searchData=
[
  ['документация_20для_20программы_20_22theshortestwayfromcity1tocityn_22_0',['Документация для программы &quot;TheShortestWayFromCity1ToCityN&quot;',['../index.html',1,'']]]
];
