var searchData=
[
  ['writeresulttotxt_0',['writeResultToTxt',['../_header_8h.html#a56a0dc274878da66af334eb79bb25733',1,'writeResultToTxt(char *data[], int minAmountOfWay[MAX_SIZE], int num_cities, int shortestPath[MAX_SIZE]):&#160;kudasov_44.cpp'],['../kudasov__44_8cpp.html#a56a0dc274878da66af334eb79bb25733',1,'writeResultToTxt(char *data[], int minAmountOfWay[MAX_SIZE], int num_cities, int shortestPath[MAX_SIZE]):&#160;kudasov_44.cpp']]]
];
