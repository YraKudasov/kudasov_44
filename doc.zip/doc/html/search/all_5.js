var searchData=
[
  ['main_0',['main',['../kudasov__44_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97',1,'kudasov_44.cpp']]],
  ['max_5fsize_1',['MAX_SIZE',['../_header_8h.html#a0592dba56693fad79136250c11e5a7fe',1,'Header.h']]]
];
