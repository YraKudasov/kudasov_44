var indexSectionsWithContent =
{
  0: "dfhikmrwд",
  1: "hk",
  2: "dfmrw",
  3: "im",
  4: "д"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "defines",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Macros",
  4: "Pages"
};

