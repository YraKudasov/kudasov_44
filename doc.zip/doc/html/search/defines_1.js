var searchData=
[
  ['max_5fsize_0',['MAX_SIZE',['../_header_8h.html#a0592dba56693fad79136250c11e5a7fe',1,'Header.h']]]
];
