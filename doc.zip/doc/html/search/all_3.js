var searchData=
[
  ['infinity_0',['infinity',['../_header_8h.html#a3e82c6787a64c6477d51900456e16ef7',1,'Header.h']]]
];
